from django.apps import AppConfig


class BookLogsConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'book_logs'
