from django.urls import path
from . import views

app_name = 'messages_app'

urlpatterns = [
    path('', views.inbox, name='inbox'),
    path('new/', views.new_message, name='new_message'),  # pick recipient
    path('<str:username>/', views.conversation, name='conversation'),
    path('<str:username>/send/', views.send_message, name='send'),
]
