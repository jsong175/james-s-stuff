from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from django.contrib.auth.models import User
from .models import Message
from django.db.models import Q, Max

@login_required
def inbox(request):
    """
    Show all users who have exchanged messages with the logged-in user.
    Sorted by most recent message.
    """
    conversations = User.objects.filter(
        Q(sent_messages__receiver=request.user) | Q(received_messages__sender=request.user)
    ).exclude(id=request.user.id).distinct()

    return render(request, 'messages_app/inbox.html', {
        'conversations': conversations
    })


@login_required
def new_message(request):
    """
    Let the user select someone to start a conversation with,
    then redirect to send_message.
    """
    users = User.objects.exclude(id=request.user.id)

    if request.method == "POST":
        other_user_id = request.POST.get("user_id")
        other_user = get_object_or_404(User, id=other_user_id)
        return redirect('messages_app:send', username=other_user.username)

    return render(request, 'messages_app/new_message.html', {'users': users})


@login_required
def conversation(request, username):
    """
    Show all messages exchanged with another user.
    """
    other_user = get_object_or_404(User, username=username)

    messages = Message.objects.filter(
        Q(sender=request.user, receiver=other_user) |
        Q(sender=other_user, receiver=request.user)
    ).order_by('timestamp')

    return render(request, 'messages_app/conversation.html', {
        'other_user': other_user,
        'messages': messages,
    })


@login_required
def send_message(request, username):
    """
    Send a message to a specific user.
    """
    other_user = get_object_or_404(User, username=username)

    if request.method == "POST":
        text = request.POST.get("text")
        if text.strip():
            Message.objects.create(
                sender=request.user,
                receiver=other_user,
                text=text
            )
        return redirect('messages_app:conversation', username=username)

    return render(request, 'messages_app/send_message.html', {
        'other_user': other_user
    })
