import pytest
from django.test import Client
from django.urls import reverse
from book_logs.models import Topic, Post

pytestmark = pytest.mark.django_db  # enable database access for all tests

def test_topic_creation():
    topic = Topic.objects.create(text="Test Topic")
    assert topic.text == "Test Topic"

def test_post_creation():
    topic = Topic.objects.create(text="Topic for Post")
    post = Post.objects.create(topic=topic, text="Hello World")
    
    assert post.text == "Hello World"
    assert post.topic.text == "Topic for Post"

def test_topic_view_nonexistent():
    """
    Edge case: access a topic page with an ID that doesn't exist.
    Expect a 404 response.
    """
    client = Client()
    nonexistent_id = 9999  # Pick an ID that almost certainly doesn't exist
    url = reverse('SongBook:topic', args=[nonexistent_id])
    
    response = client.get(url)
    
    assert response.status_code == 404

def test_topic_view_existing():
    """
    Normal case: access a topic page that exists.
    """
    topic = Topic.objects.create(text="Existing Topic")
    client = Client()
    url = reverse('SongBook:topic', args=[topic.id])
    
    response = client.get(url)
    
    assert response.status_code == 200
    assert topic.text.encode() in response.content  # page contains topic text
